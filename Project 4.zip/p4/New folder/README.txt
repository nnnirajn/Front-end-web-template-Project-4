A Pen created at CodePen.io. You can find this one at https://codepen.io/mattgrosswork/pen/jrdwK.

 Nifty newish html5 in a simple format.